﻿Public Class dlgAbout

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub

    Private Sub pnlTabs_Paint(sender As Object, e As PaintEventArgs) Handles pnlTabs.Paint

    End Sub
End Class