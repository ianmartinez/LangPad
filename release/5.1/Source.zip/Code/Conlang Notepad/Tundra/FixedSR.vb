﻿Imports System.Windows.Forms

Public Class FixedSR
    Inherits ToolStripSystemRenderer

    Protected Overrides Sub OnRenderToolStripBorder(ByVal e As System.Windows.Forms.ToolStripRenderEventArgs)

    End Sub
End Class
